using Godot;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

public partial class GemGUI : Control
{
	[Export]
	UnitCrystal crystal;
	[Export]
	OptionButton crystalSystem;
	[Export]
	SpinBox[] crystalParams = new SpinBox[6];
	private bool autoUpdate = true;
	private bool updatedParamsThisFrame = false;
	private bool updatedNormsThisFrame = false;
	[Export]
	Container vectorList;
	[Export]
	public PackedScene spinBox;
	private List<VectorListItem> listItems = new List<VectorListItem>();


	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		AddNewNormal();
		AddNewNormal();
		AddNewNormal();
		AddNewNormal();
		listItems[0].SetValues(new(3, 1, 0), 1);//Defaults
		listItems[1].SetValues(new(0, 5, 1), .9f);
		listItems[2].SetValues(new(-1, -1, -1), 1);
		listItems[3].SetValues(new(-2, 0, -1), 1);
		foreach (VectorListItem item in listItems)
		{
			SetNormals(item.index, item.vector, item.distance);
		}
		crystalSystem.Select(22);//-3rhomb
		SetCrystalSystem(22);
		crystal.CallDeferred("UpdateFromParameters");
		crystal.CallDeferred("UpdateMesh");
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		updatedParamsThisFrame = false;
		updatedNormsThisFrame = false;
	}

	public void SetAutoUpdate(bool update)
	{
		autoUpdate = update;
	}
	public void SetAutoRotate(bool update)
	{
		crystal.RotateCrystal = update;
	}
	public void SetCrystalSystem(int num)
	{
		crystal.PointGroup = (SymmetryOperations.PointGroup)(crystalSystem.GetItemId(num) / 10);
		//GD.Print(crystal.PointGroup.ToString());
		float[] parameters = SymmetryOperations.GetParametersForPointGroup(crystal.PointGroup);
		for (int i = 0; i < 6; i++)
			crystalParams[i].SetValueNoSignal(parameters[i]);
		CheckParamUpdate();
		crystal.CallDeferred("UpdateMesh");
	}
	public void SetColor(Color color)
	{
		StandardMaterial3D material = (StandardMaterial3D)crystal.MaterialOverride;
		material.AlbedoColor = color;
	}
	private void CheckParamUpdate()
	{
		if (autoUpdate == false || updatedParamsThisFrame)
			return;
		updatedParamsThisFrame = true;
		crystal.CallDeferred("UpdateFromParameters");
	}
	private void CheckNormUpdate()
	{
		if (autoUpdate == false || updatedNormsThisFrame)
			return;
		updatedNormsThisFrame = true;
		crystal.CallDeferred("UpdateMesh");
	}
	public void SetA(float a) { crystal.aLength = a; CheckParamUpdate(); }
	public void SetB(float b) { crystal.bLength = b; CheckParamUpdate(); }
	public void SetC(float c) { crystal.cLength = c; CheckParamUpdate(); }
	public void SetAlpha(float alpha) { crystal.alpha = alpha; CheckParamUpdate(); }
	public void SetBeta(float beta) { crystal.beta = beta; CheckParamUpdate(); }
	public void SetGamma(float gamma) { crystal.gamma = gamma; CheckParamUpdate(); }
	public void AddNewNormal()
	{
		VectorListItem listItem = new VectorListItem();
		listItem.index = listItems.Count;
		listItems.Add(listItem);

		SpinBox h = (SpinBox)spinBox.Instantiate();
		SpinBox j = (SpinBox)spinBox.Instantiate();
		SpinBox k = (SpinBox)spinBox.Instantiate();
		SpinBox d = (SpinBox)spinBox.Instantiate();
		d.MinValue = 0.01f;
		d.MaxValue = 2;
		Button x = new Button();
		x.Text = "X";

		listItem.boxes[0] = h;
		listItem.boxes[1] = j;
		listItem.boxes[2] = k;
		listItem.boxes[3] = d;
		listItem.button = x;

		listItem.SetValues(Vector3.One, 1);
		SetNormals(listItem.index, listItem.vector, listItem.distance);

		h.ValueChanged += listItem.SetX;
		j.ValueChanged += listItem.SetY;
		k.ValueChanged += listItem.SetZ;
		d.ValueChanged += listItem.SetDistance;
		x.Pressed += listItem.Remove;

		listItem.Update += SetNormals;
		listItem.Delet += RemoveNormals;

		vectorList.AddChild(h);
		vectorList.AddChild(j);
		vectorList.AddChild(k);
		vectorList.AddChild(d);
		vectorList.AddChild(x);
	}
	public void SetNormals(int idx, Vector3 normal, float distance)
	{
		if (normal.IsZeroApprox() || distance == 0)
			return;
		if (crystal.Normals.Length <= idx || crystal.Distances.Length <= idx)
		{
			Vector3[] newNormals = new Vector3[idx + 2];
			float[] newDistances = new float[idx + 2];
			crystal.Normals.CopyTo(newNormals, 0);
			crystal.Distances.CopyTo(newDistances, 0);
			crystal.Normals = newNormals;
			crystal.Distances = newDistances;
		}
		crystal.Normals[idx] = normal;
		crystal.Distances[idx] = distance;
		CheckNormUpdate();
	}
	public void RemoveNormals(int idx)
	{
		listItems[idx].boxes[0].QueueFree();
		listItems[idx].boxes[1].QueueFree();
		listItems[idx].boxes[2].QueueFree();
		listItems[idx].boxes[3].QueueFree();
		listItems[idx].button.QueueFree();
		listItems[idx].QueueFree();

		for (int i = idx + 1; i < listItems.Count; i++)
			listItems[i].index--;
		listItems.RemoveAt(idx);

		List<Vector3> normals = crystal.Normals.ToList<Vector3>();
		List<float> distances = crystal.Distances.ToList<float>();
		normals.RemoveAt(idx);
		distances.RemoveAt(idx);
		crystal.Normals = normals.ToArray();
		crystal.Distances = distances.ToArray();

		CheckNormUpdate();
	}
}
